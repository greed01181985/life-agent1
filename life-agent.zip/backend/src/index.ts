import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { v4 as uuid } from 'uuid';
import {
  getAuthUrl,
  handleCallback,
  tokenStore,
  getCalendarEvents,
  findConflicts,
  createGmailDraft,
  updateCalendarEvent,
  isGoogleConfigured,
} from './google.js';

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());

// In-memory store for MVP (replace with Postgres later)
const users = new Map<string, any>();
const conversations = new Map<string, any[]>();
const briefings = new Map<string, any>();
const approvals = new Map<string, any[]>();

// Simple auth middleware (demo only)
function auth(req: any, res: any, next: any) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    req.userId = 'demo-user';
    return next();
  }
  req.userId = header.slice(7) || 'demo-user';
  next();
}

app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'life-agent-backend',
    version: '0.1.0',
    googleConfigured: isGoogleConfigured(),
  });
});

// --- Auth (very simple for now) ---
app.post('/auth/signup', (req, res) => {
  const { email, password, name } = req.body;
  const id = uuid();
  const user = {
    id,
    email,
    name: name || email.split('@')[0],
    avatarUrl: null,
    createdAt: new Date().toISOString(),
    preferences: {
      timezone: 'America/New_York',
      briefingTime: '07:30',
      tone: 'friendly',
      autoApproveLowRisk: false,
      notificationsEnabled: true,
    },
  };
  users.set(id, user);
  res.json({ token: id, user });
});

app.post('/auth/login', (req, res) => {
  const { email } = req.body;
  const user = {
    id: 'demo-user',
    email,
    name: email.split('@')[0],
    avatarUrl: null,
    createdAt: new Date().toISOString(),
    preferences: {
      timezone: 'America/New_York',
      briefingTime: '07:30',
      tone: 'friendly',
      autoApproveLowRisk: false,
      notificationsEnabled: true,
    },
  };
  res.json({ token: 'demo-user', user });
});

app.get('/me', auth, (req: any, res) => {
  const google = tokenStore.get(req.userId);
  res.json({
    id: req.userId,
    email: google?.email || 'you@example.com',
    name: google?.name || 'Alex',
    avatarUrl: null,
    createdAt: new Date().toISOString(),
    preferences: {
      timezone: 'America/New_York',
      briefingTime: '07:30',
      tone: 'friendly',
      autoApproveLowRisk: false,
      notificationsEnabled: true,
    },
    googleConnected: Boolean(google),
  });
});

// --- Google OAuth ---
app.get('/connections/google/start', auth, (req: any, res) => {
  if (!isGoogleConfigured()) {
    return res.status(503).json({
      error: 'Google OAuth not configured',
      message:
        'Set GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, and GOOGLE_REDIRECT_URI environment variables.',
    });
  }

  // state carries the userId so we know who is connecting
  const state = req.userId;
  const url = getAuthUrl(state);
  res.json({ url });
});

app.get('/connections/google/callback', async (req, res) => {
  const { code, state, error } = req.query;

  if (error) {
    return res.status(400).send(`
      <html><body style="font-family: system-ui; padding: 40px; background: #0f172a; color: #f8fafc;">
        <h2>Connection failed</h2>
        <p>${error}</p>
        <p>You can close this window.</p>
      </body></html>
    `);
  }

  if (!code || typeof code !== 'string') {
    return res.status(400).send('Missing code');
  }

  try {
    const { tokens, email, name } = await handleCallback(code);
    const userId = (state as string) || 'demo-user';

    tokenStore.set(userId, {
      access_token: tokens.access_token!,
      refresh_token: tokens.refresh_token || undefined,
      expiry_date: tokens.expiry_date || undefined,
      email,
      name,
    });

    // Success page that can deep-link back to the app
    res.send(`
      <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <style>
            body { font-family: system-ui, -apple-system, sans-serif; background: #0f172a; color: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
            .card { background: #1e293b; border-radius: 16px; padding: 32px; max-width: 360px; text-align: center; border: 1px solid #334155; }
            h2 { margin: 0 0 8px; }
            p { color: #94a3b8; margin: 0 0 24px; }
            a { display: inline-block; background: #3b82f6; color: white; text-decoration: none; padding: 12px 24px; border-radius: 10px; font-weight: 600; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>Google connected ✓</h2>
            <p>${email || 'Your account'} is now linked to Life Agent.</p>
            <a href="lifeagent://connections/success">Back to app</a>
          </div>
          <script>
            // Try to auto-redirect to the app
            setTimeout(() => { window.location.href = 'lifeagent://connections/success'; }, 1500);
          </script>
        </body>
      </html>
    `);
  } catch (err: any) {
    console.error('OAuth callback error:', err);
    res.status(500).send(`
      <html><body style="font-family: system-ui; padding: 40px; background: #0f172a; color: #f8fafc;">
        <h2>Something went wrong</h2>
        <p>${err.message || 'Unknown error'}</p>
      </body></html>
    `);
  }
});

app.get('/connections', auth, (req: any, res) => {
  const google = tokenStore.get(req.userId);
  const connections = [];

  if (google) {
    connections.push({
      provider: 'google',
      type: 'both',
      email: google.email,
      connectedAt: new Date().toISOString(),
      scopes: ['calendar', 'gmail'],
      status: 'active',
    });
  }

  res.json(connections);
});

app.delete('/connections/google', auth, (req: any, res) => {
  tokenStore.delete(req.userId);
  res.json({ ok: true });
});

// --- Calendar helpers ---
app.get('/calendar/events', auth, async (req: any, res) => {
  try {
    const events = await getCalendarEvents(req.userId);
    res.json(events);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/calendar/conflicts', auth, async (req: any, res) => {
  try {
    const conflicts = await findConflicts(req.userId);
    res.json(conflicts);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// --- Chat ---
app.post('/chat', auth, async (req: any, res) => {
  const { content, conversationId } = req.body;
  const convId = conversationId || uuid();

  if (!conversations.has(convId)) {
    conversations.set(convId, []);
  }

  const history = conversations.get(convId)!;

  const userMsg = {
    id: uuid(),
    role: 'user',
    content,
    createdAt: new Date().toISOString(),
  };
  history.push(userMsg);

  let reply =
    "I'm your Life Agent. Connect Google Calendar and Gmail in Settings so I can give you real briefings and catch conflicts.";

  const lower = content.toLowerCase();
  const hasGoogle = tokenStore.has(req.userId);

  try {
    if (hasGoogle && (lower.includes('briefing') || lower.includes('today') || lower.includes('schedule'))) {
      const events = await getCalendarEvents(req.userId);
      const conflicts = await findConflicts(req.userId);

      if (events.length === 0) {
        reply = "Your calendar looks clear for the next 7 days. Enjoy the breathing room!";
      } else {
        const todayStr = new Date().toISOString().slice(0, 10);
        const todayEvents = events.filter((e) => e.start?.startsWith(todayStr));
        const lines = todayEvents
          .slice(0, 5)
          .map((e) => {
            const time = e.start?.includes('T')
              ? new Date(e.start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              : 'All day';
            return `• ${time} – ${e.summary}`;
          });

        reply = `Here's what's on your calendar today:\n\n${lines.join('\n') || 'Nothing scheduled.'}`;

        if (conflicts.length > 0) {
          reply += `\n\n⚠️ I found ${conflicts.length} scheduling conflict(s). Open the Briefing tab for details and proposed fixes.`;
        }
      }
    } else if (hasGoogle && (lower.includes('conflict') || lower.includes('overlap'))) {
      const conflicts = await findConflicts(req.userId);
      if (conflicts.length === 0) {
        reply = 'No scheduling conflicts detected in the next 7 days. Looking good!';
      } else {
        const desc = conflicts
          .slice(0, 3)
          .map(
            (c) =>
              `• "${c.a.summary}" overlaps with "${c.b.summary}"`
          )
          .join('\n');
        reply = `Found ${conflicts.length} conflict(s):\n\n${desc}\n\nI can draft a reschedule email or move one of the events. Just say the word.`;
      }
    } else if (lower.includes('email') || lower.includes('draft')) {
      reply = hasGoogle
        ? "I've prepared a draft. Open the Approvals tab to review and create it in Gmail with one tap."
        : 'Connect Gmail in Settings first so I can create drafts for you.';
    } else if (lower.includes('hello') || lower.includes('hi')) {
      reply = hasGoogle
        ? "Hey! Google is connected. Ask me about your schedule, to check for conflicts, or say \"give me today's briefing\"."
        : "Hey! Connect Google in Settings and I'll be able to read your calendar and draft emails.";
    } else if (hasGoogle) {
      reply =
        "I can check your calendar, find conflicts, draft emails, and generate a daily briefing. What would you like?";
    }
  } catch (err: any) {
    console.error('Chat agent error:', err);
    reply = `Something went wrong talking to Google: ${err.message}`;
  }

  const assistantMsg = {
    id: uuid(),
    role: 'assistant',
    content: reply,
    createdAt: new Date().toISOString(),
  };
  history.push(assistantMsg);

  res.json({
    conversationId: convId,
    messages: [userMsg, assistantMsg],
  });
});

// --- Briefing (now uses real calendar when connected) ---
app.get('/briefing/today', auth, (req: any, res) => {
  const key = `${req.userId}:${new Date().toISOString().slice(0, 10)}`;
  res.json(briefings.get(key) || null);
});

app.post('/briefing/generate', auth, async (req: any, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const hasGoogle = tokenStore.has(req.userId);

  let sections: any[] = [];
  let summary = 'Connect Google Calendar to get a personalized briefing.';
  let proposed: any[] = [];

  if (hasGoogle) {
    try {
      const events = await getCalendarEvents(req.userId);
      const conflicts = await findConflicts(req.userId);

      const todayEvents = events.filter((e) => e.start?.startsWith(today));

      sections.push({
        title: "Today's Schedule",
        items: todayEvents.map((e) => ({
          id: e.id,
          type: 'event',
          title: e.summary,
          subtitle: e.location || undefined,
          time: e.start?.includes('T')
            ? new Date(e.start).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
              })
            : 'All day',
          priority: 'medium',
          actionable: true,
        })),
      });

      if (conflicts.length > 0) {
        sections.push({
          title: 'Attention Needed',
          items: conflicts.map((c, i) => ({
            id: `conflict-${i}`,
            type: 'alert',
            title: 'Scheduling conflict',
            subtitle: `"${c.a.summary}" overlaps with "${c.b.summary}"`,
            priority: 'high',
            actionable: true,
          })),
        });

        // Propose actions for the first conflict
        const c = conflicts[0];
        proposed.push({
          id: uuid(),
          type: 'reschedule',
          title: `Reschedule "${c.a.summary}"`,
          description: `Move this event so it no longer conflicts with "${c.b.summary}".`,
          payload: {
            eventId: c.a.id,
            // Suggest 1 hour later as a simple default
          },
          riskLevel: 'medium',
          status: 'pending',
          createdAt: new Date().toISOString(),
        });

        proposed.push({
          id: uuid(),
          type: 'draft_email',
          title: 'Draft reschedule email',
          description: `Polite email proposing a new time for "${c.a.summary}".`,
          payload: {
            subject: `Quick reschedule request – ${c.a.summary}`,
            body: `Hi,\n\nWould it be possible to move "${c.a.summary}"? It currently overlaps with another commitment.\n\nThanks!`,
          },
          riskLevel: 'low',
          status: 'pending',
          createdAt: new Date().toISOString(),
        });
      }

      summary =
        todayEvents.length === 0
          ? 'Your calendar is clear today.'
          : `You have ${todayEvents.length} event(s) today${
              conflicts.length > 0
                ? ` and ${conflicts.length} scheduling conflict(s)`
                : ''
            }.`;
    } catch (err: any) {
      summary = `Could not load calendar: ${err.message}`;
    }
  } else {
    // Demo data when not connected
    sections = [
      {
        title: "Today's Schedule (demo)",
        items: [
          {
            id: '1',
            type: 'event',
            title: 'Team standup',
            subtitle: 'Zoom',
            time: '09:30',
            priority: 'medium',
          },
          {
            id: '2',
            type: 'event',
            title: 'Design review',
            subtitle: 'Conference room B',
            time: '14:00',
            priority: 'high',
            actionable: true,
          },
        ],
      },
    ];
    summary =
      'This is demo data. Connect Google Calendar in Settings for your real schedule.';
  }

  const briefing = {
    id: uuid(),
    date: today,
    summary,
    sections,
    proposedActions: proposed,
    generatedAt: new Date().toISOString(),
  };

  const key = `${req.userId}:${today}`;
  briefings.set(key, briefing);

  if (proposed.length > 0) {
    approvals.set(req.userId, proposed);
  }

  res.json(briefing);
});

// --- Approvals ---
app.get('/approvals', auth, (req: any, res) => {
  res.json(approvals.get(req.userId) || []);
});

app.post('/approvals/:id', auth, async (req: any, res) => {
  const { status, editedPayload } = req.body;
  const list = approvals.get(req.userId) || [];
  let action = list.find((a: any) => a.id === req.params.id);

  if (!action) {
    return res.status(404).json({ error: 'Action not found' });
  }

  // If approved, try to execute
  if (status === 'approved' && tokenStore.has(req.userId)) {
    try {
      if (action.type === 'draft_email') {
        const payload = editedPayload || action.payload;
        await createGmailDraft(
          req.userId,
          payload.to || 'me',
          payload.subject || 'No subject',
          payload.body || ''
        );
      }
      // reschedule would call updateCalendarEvent here
    } catch (err: any) {
      console.error('Failed to execute action:', err);
      return res.status(500).json({ error: `Execution failed: ${err.message}` });
    }
  }

  const updated = list.map((a: any) =>
    a.id === req.params.id ? { ...a, status, payload: editedPayload || a.payload } : a
  );
  approvals.set(req.userId, updated);
  action = updated.find((a: any) => a.id === req.params.id);
  res.json(action);
});

app.listen(PORT, () => {
  console.log(`Life Agent backend running on http://localhost:${PORT}`);
  console.log(`Google OAuth configured: ${isGoogleConfigured()}`);
});
