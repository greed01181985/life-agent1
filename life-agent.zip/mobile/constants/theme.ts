export const colors = {
  // Core
  background: '#070b14',
  surface: '#111827',
  surfaceElevated: '#1a2332',
  surfaceHighlight: '#243044',

  // Brand
  primary: '#3b82f6',
  primarySoft: '#3b82f615',
  primaryMuted: '#2563eb',
  accent: '#22d3ee',
  accentSoft: '#22d3ee18',

  // Text
  text: '#f1f5f9',
  textSecondary: '#94a3b8',
  textMuted: '#64748b',
  textInverse: '#0f172a',

  // Semantic
  success: '#22c55e',
  successSoft: '#22c55e18',
  warning: '#f59e0b',
  warningSoft: '#f59e0b18',
  danger: '#ef4444',
  dangerSoft: '#ef444418',

  // Borders
  border: '#1e293b',
  borderLight: '#334155',

  overlay: 'rgba(0,0,0,0.55)',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  full: 999,
};

export const typography = {
  hero: {
    fontSize: 32,
    fontWeight: '700' as const,
    letterSpacing: -0.5,
  },
  title: {
    fontSize: 22,
    fontWeight: '700' as const,
    letterSpacing: -0.3,
  },
  subtitle: {
    fontSize: 17,
    fontWeight: '600' as const,
  },
  body: {
    fontSize: 15,
    fontWeight: '400' as const,
    lineHeight: 22,
  },
  caption: {
    fontSize: 13,
    fontWeight: '500' as const,
  },
  label: {
    fontSize: 12,
    fontWeight: '600' as const,
    letterSpacing: 0.4,
    textTransform: 'uppercase' as const,
  },
};
