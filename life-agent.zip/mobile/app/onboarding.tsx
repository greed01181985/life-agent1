import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { IconCircle, PrimaryButton } from '@/components/ui';

const FEATURES = [
  { icon: 'sunny' as const, text: 'Daily briefing every morning' },
  { icon: 'warning' as const, text: 'Catches conflicts before they happen' },
  { icon: 'mail' as const, text: 'Drafts emails & messages for you' },
  { icon: 'shield-checkmark' as const, text: 'Never acts without your approval' },
];

export default function OnboardingScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.hero}>
          <IconCircle name="sparkles" color={colors.accent} size={88} />
          <Text style={styles.title}>Meet your Life Agent</Text>
          <Text style={styles.subtitle}>
            A proactive chief-of-staff that watches your calendar, inbox, and life admin so you
            don’t have to.
          </Text>
        </View>

        <View style={styles.features}>
          {FEATURES.map((f) => (
            <View key={f.text} style={styles.featureRow}>
              <IconCircle name={f.icon} color={colors.primary} size={40} />
              <Text style={styles.featureText}>{f.text}</Text>
            </View>
          ))}
        </View>

        <PrimaryButton
          title="Get Started"
          icon="arrow-forward"
          onPress={() => router.replace('/')}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    padding: spacing.xl,
    justifyContent: 'space-between',
  },
  hero: {
    alignItems: 'center',
    marginTop: 32,
    gap: 12,
  },
  title: {
    ...typography.hero,
    color: colors.text,
    textAlign: 'center',
    marginTop: 8,
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 23,
    paddingHorizontal: 8,
  },
  features: {
    gap: 12,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: colors.surface,
    padding: 14,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  featureText: {
    fontSize: 15,
    color: colors.text,
    flex: 1,
    fontWeight: '500',
  },
});
