import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { useAppStore } from '@/lib/store';
import { Card, EmptyState } from '@/components/ui';
import type { ProposedAction } from '@/types';

const DEMO_ACTIONS: ProposedAction[] = [
  {
    id: 'a1',
    type: 'reschedule',
    title: 'Reschedule Design Review',
    description:
      'Move the 2:00pm Design Review to 3:30pm so it no longer conflicts with the Acme client call.',
    payload: {},
    riskLevel: 'medium',
    status: 'pending',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'a2',
    type: 'draft_email',
    title: 'Draft: Reschedule request',
    description:
      'Polite email to the design team proposing the new time and explaining the client conflict.',
    payload: {},
    riskLevel: 'low',
    status: 'pending',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'a3',
    type: 'create_reminder',
    title: 'Reminder: Notion renewal',
    description: 'Remind me in 3 days to review whether to keep the Notion subscription.',
    payload: {},
    riskLevel: 'low',
    status: 'pending',
    createdAt: new Date().toISOString(),
  },
];

function ActionCard({
  action,
  onRespond,
}: {
  action: ProposedAction;
  onRespond: (id: string, status: 'approved' | 'rejected') => void;
}) {
  const riskColor =
    action.riskLevel === 'high'
      ? colors.danger
      : action.riskLevel === 'medium'
        ? colors.warning
        : colors.success;

  return (
    <Card style={styles.card}>
      <View style={styles.cardHeader}>
        <View style={[styles.riskBadge, { backgroundColor: riskColor + '20' }]}>
          <Text style={[styles.riskText, { color: riskColor }]}>
            {action.riskLevel.toUpperCase()}
          </Text>
        </View>
        <Text style={styles.typeLabel}>{action.type.replace('_', ' ')}</Text>
      </View>

      <Text style={styles.title}>{action.title}</Text>
      <Text style={styles.description}>{action.description}</Text>

      {action.status === 'pending' ? (
        <View style={styles.actions}>
          <TouchableOpacity
            style={[styles.btn, styles.rejectBtn]}
            onPress={() => onRespond(action.id, 'rejected')}
            activeOpacity={0.8}
          >
            <Ionicons name="close" size={18} color={colors.danger} />
            <Text style={[styles.btnText, { color: colors.danger }]}>Dismiss</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.btn, styles.approveBtn]}
            onPress={() => onRespond(action.id, 'approved')}
            activeOpacity={0.85}
          >
            <Ionicons name="checkmark" size={18} color="#fff" />
            <Text style={[styles.btnText, { color: '#fff' }]}>Approve</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.resolved}>
          <Ionicons
            name={action.status === 'approved' ? 'checkmark-circle' : 'close-circle'}
            size={18}
            color={action.status === 'approved' ? colors.success : colors.textMuted}
          />
          <Text style={styles.resolvedText}>
            {action.status === 'approved' ? 'Approved' : 'Dismissed'}
          </Text>
        </View>
      )}
    </Card>
  );
}

export default function ApprovalsScreen() {
  const { pendingApprovals, setPendingApprovals, updateApproval } = useAppStore();
  const actions = pendingApprovals.length > 0 ? pendingApprovals : DEMO_ACTIONS;

  const handleRespond = (id: string, status: 'approved' | 'rejected') => {
    updateApproval(id, status);
    if (pendingApprovals.length === 0) {
      setPendingApprovals(DEMO_ACTIONS.map((a) => (a.id === id ? { ...a, status } : a)));
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <FlatList
        data={actions}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <Text style={styles.headerText}>
            Review actions your agent wants to take. Nothing happens without your OK.
          </Text>
        }
        ListEmptyComponent={
          <EmptyState
            icon="checkmark-done-circle"
            title="All clear"
            subtitle="No pending approvals right now."
          />
        }
        renderItem={({ item }) => (
          <ActionCard action={item} onRespond={handleRespond} />
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  list: {
    padding: spacing.lg,
    gap: spacing.md,
    paddingBottom: spacing.xxl,
  },
  headerText: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
    lineHeight: 21,
  },
  card: {
    marginBottom: 4,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 10,
  },
  riskBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  riskText: {
    fontSize: 11,
    fontWeight: '700',
  },
  typeLabel: {
    fontSize: 12,
    color: colors.textMuted,
    textTransform: 'capitalize',
  },
  title: {
    ...typography.subtitle,
    color: colors.text,
    marginBottom: 6,
  },
  description: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: 16,
  },
  actions: {
    flexDirection: 'row',
    gap: 10,
  },
  btn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: radius.md,
  },
  rejectBtn: {
    backgroundColor: colors.dangerSoft,
    borderWidth: 1,
    borderColor: colors.danger + '35',
  },
  approveBtn: {
    backgroundColor: colors.primary,
  },
  btnText: {
    fontWeight: '600',
    fontSize: 15,
  },
  resolved: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  resolvedText: {
    color: colors.textMuted,
    fontSize: 14,
  },
});
