import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { useAppStore } from '@/lib/store';
import { Card, IconCircle } from '@/components/ui';
import type { BriefingItem } from '@/types';

const DEMO_BRIEFING = {
  id: 'demo-1',
  date: new Date().toISOString().slice(0, 10),
  summary:
    'You have a busy afternoon with a potential scheduling conflict. One subscription renewal is coming up this week.',
  sections: [
    {
      title: "Today’s Schedule",
      items: [
        {
          id: '1',
          type: 'event' as const,
          title: 'Team standup',
          subtitle: 'Zoom',
          time: '09:30',
          priority: 'medium' as const,
        },
        {
          id: '2',
          type: 'event' as const,
          title: 'Design review',
          subtitle: 'Conference room B',
          time: '14:00',
          priority: 'high' as const,
          actionable: true,
        },
        {
          id: '3',
          type: 'event' as const,
          title: 'Client call – Acme',
          subtitle: 'Google Meet',
          time: '14:30',
          priority: 'high' as const,
          actionable: true,
        },
      ],
    },
    {
      title: 'Attention Needed',
      items: [
        {
          id: '4',
          type: 'alert' as const,
          title: 'Scheduling conflict',
          subtitle: 'Design review overlaps with client call',
          priority: 'high' as const,
          actionable: true,
        },
        {
          id: '5',
          type: 'alert' as const,
          title: 'Notion subscription renews in 4 days',
          subtitle: '$20 / month',
          priority: 'medium' as const,
          actionable: true,
        },
      ],
    },
    {
      title: 'Insights',
      items: [
        {
          id: '6',
          type: 'insight' as const,
          title: 'You have 2 free hours between 11:00–13:00',
          priority: 'low' as const,
        },
      ],
    },
  ],
  proposedActions: [],
  generatedAt: new Date().toISOString(),
};

function ItemRow({ item }: { item: BriefingItem }) {
  const iconMap = {
    event: 'calendar',
    task: 'checkbox',
    email: 'mail',
    alert: 'warning',
    insight: 'bulb',
  } as const;

  const colorMap = {
    high: colors.danger,
    medium: colors.warning,
    low: colors.textMuted,
  };

  return (
    <View style={styles.item}>
      <IconCircle
        name={iconMap[item.type] as any}
        color={colorMap[item.priority]}
        size={38}
      />
      <View style={styles.itemBody}>
        <Text style={styles.itemTitle}>{item.title}</Text>
        {item.subtitle && <Text style={styles.itemSubtitle}>{item.subtitle}</Text>}
      </View>
      {item.time && <Text style={styles.itemTime}>{item.time}</Text>}
    </View>
  );
}

export default function BriefingScreen() {
  const { todayBriefing, setTodayBriefing } = useAppStore();
  const briefing = todayBriefing || DEMO_BRIEFING;

  const generate = () => {
    setTodayBriefing(DEMO_BRIEFING as any);
  };

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Summary hero */}
        <Card style={styles.summaryCard}>
          <Text style={styles.dateLabel}>
            {new Date(briefing.date).toLocaleDateString(undefined, {
              weekday: 'long',
              month: 'long',
              day: 'numeric',
            })}
          </Text>
          <Text style={styles.summary}>{briefing.summary}</Text>
        </Card>

        {briefing.sections.map((section) => (
          <View key={section.title} style={styles.section}>
            <Text style={styles.sectionTitle}>{section.title}</Text>
            <View style={styles.sectionList}>
              {section.items.map((item) => (
                <ItemRow key={item.id} item={item} />
              ))}
            </View>
          </View>
        ))}

        <TouchableOpacity style={styles.regenerateBtn} onPress={generate} activeOpacity={0.8}>
          <Ionicons name="refresh" size={18} color={colors.primary} />
          <Text style={styles.regenerateText}>Regenerate Briefing</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
    gap: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  summaryCard: {
    gap: 8,
  },
  dateLabel: {
    ...typography.caption,
    color: colors.accent,
    fontWeight: '600',
  },
  summary: {
    ...typography.body,
    color: colors.text,
    fontSize: 16,
    lineHeight: 24,
  },
  section: {
    gap: 10,
  },
  sectionTitle: {
    ...typography.label,
    color: colors.textMuted,
  },
  sectionList: {
    gap: 8,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    padding: 12,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 12,
  },
  itemBody: {
    flex: 1,
  },
  itemTitle: {
    fontSize: 15,
    fontWeight: '500',
    color: colors.text,
  },
  itemSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    marginTop: 2,
  },
  itemTime: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textMuted,
  },
  regenerateBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 14,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    borderStyle: 'dashed',
  },
  regenerateText: {
    color: colors.primary,
    fontWeight: '600',
    fontSize: 15,
  },
});
