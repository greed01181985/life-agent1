import { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Switch,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { useAppStore } from '@/lib/store';
import { api } from '@/lib/api';
import { Card, SectionLabel } from '@/components/ui';
import type { ConnectedAccount } from '@/types';

export default function SettingsScreen() {
  const { user, setUser, reset } = useAppStore();
  const [connections, setConnections] = useState<ConnectedAccount[]>([]);
  const [loading, setLoading] = useState(false);
  const [connecting, setConnecting] = useState(false);

  const loadConnections = useCallback(async () => {
    try {
      setLoading(true);
      const [accounts, me] = await Promise.all([
        api.getConnectedAccounts(),
        api.getMe().catch(() => null),
      ]);
      setConnections(accounts);
      if (me) setUser(me);
    } catch {
      // backend may not be running
    } finally {
      setLoading(false);
    }
  }, [setUser]);

  useFocusEffect(
    useCallback(() => {
      loadConnections();
    }, [loadConnections])
  );

  const googleConnection = connections.find((c) => c.provider === 'google');

  const connectGoogle = async () => {
    try {
      setConnecting(true);
      const { url } = await api.startGoogleOAuth();
      const result = await WebBrowser.openAuthSessionAsync(
        url,
        'lifeagent://connections/success'
      );
      if (result.type === 'success' || result.type === 'dismiss') {
        setTimeout(() => loadConnections(), 800);
      }
    } catch (err: any) {
      Alert.alert(
        'Could not start Google login',
        err?.response?.data?.message ||
          err?.message ||
          'Make sure the backend is running and Google OAuth is configured.'
      );
    } finally {
      setConnecting(false);
    }
  };

  const disconnectGoogle = () => {
    Alert.alert('Disconnect Google', 'Remove Calendar and Gmail access?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Disconnect',
        style: 'destructive',
        onPress: async () => {
          try {
            await api.disconnectGoogle();
            setConnections([]);
          } catch {
            Alert.alert('Error', 'Could not disconnect');
          }
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <SectionLabel>Account</SectionLabel>
        <Card>
          <View style={styles.row}>
            <Ionicons name="person-circle" size={42} color={colors.primary} />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={styles.name}>{user?.name || 'Guest User'}</Text>
              <Text style={styles.email}>{user?.email || 'Not signed in'}</Text>
            </View>
          </View>
        </Card>

        <SectionLabel>Connected Accounts</SectionLabel>
        <Card padded={false}>
          <TouchableOpacity
            style={styles.row}
            onPress={googleConnection ? disconnectGoogle : connectGoogle}
            disabled={connecting || loading}
            activeOpacity={0.7}
          >
            <View style={styles.iconBox}>
              <Ionicons name="logo-google" size={22} color="#ea4335" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>Google</Text>
              <Text style={styles.rowSubtitle}>
                {googleConnection
                  ? googleConnection.email || 'Calendar + Gmail'
                  : 'Calendar + Gmail'}
              </Text>
            </View>
            {connecting || loading ? (
              <ActivityIndicator color={colors.primary} />
            ) : googleConnection ? (
              <View style={styles.connectedBadge}>
                <Ionicons name="checkmark-circle" size={16} color={colors.success} />
                <Text style={styles.connectedText}>Connected</Text>
              </View>
            ) : (
              <Text style={styles.connectText}>Connect</Text>
            )}
          </TouchableOpacity>
        </Card>

        <Text style={styles.hint}>
          We only request Calendar and Gmail access. The agent never sends or changes anything
          without your explicit approval.
        </Text>

        <SectionLabel>Preferences</SectionLabel>
        <Card padded={false}>
          <View style={styles.row}>
            <Text style={styles.rowTitle}>Daily briefing time</Text>
            <Text style={styles.rowValue}>07:30</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.row}>
            <Text style={styles.rowTitle}>Tone</Text>
            <Text style={styles.rowValue}>Friendly</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.row}>
            <Text style={styles.rowTitle}>Auto-approve low risk</Text>
            <Switch
              value={false}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="#fff"
            />
          </View>
          <View style={styles.divider} />
          <View style={styles.row}>
            <Text style={styles.rowTitle}>Push notifications</Text>
            <Switch
              value={true}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="#fff"
            />
          </View>
        </Card>

        <TouchableOpacity style={styles.logoutBtn} onPress={() => reset()} activeOpacity={0.8}>
          <Text style={styles.logoutText}>Sign out</Text>
        </TouchableOpacity>

        <Text style={styles.version}>Life Agent v0.1.0</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
    gap: spacing.md,
    paddingBottom: spacing.xxl,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
  },
  iconBox: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: colors.surfaceElevated,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  name: {
    fontSize: 17,
    fontWeight: '600',
    color: colors.text,
  },
  email: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 1,
  },
  rowTitle: {
    fontSize: 16,
    color: colors.text,
    flex: 1,
  },
  rowSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
  },
  rowValue: {
    fontSize: 15,
    color: colors.textSecondary,
  },
  connectText: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.primary,
  },
  connectedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  connectedText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.success,
  },
  hint: {
    fontSize: 13,
    color: colors.textMuted,
    lineHeight: 18,
    marginTop: -4,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginLeft: spacing.md,
  },
  logoutBtn: {
    marginTop: spacing.md,
    padding: 14,
    borderRadius: radius.md,
    backgroundColor: colors.dangerSoft,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.danger + '30',
  },
  logoutText: {
    color: colors.danger,
    fontWeight: '600',
    fontSize: 16,
  },
  version: {
    textAlign: 'center',
    color: colors.textMuted,
    fontSize: 13,
    marginTop: spacing.sm,
  },
});
