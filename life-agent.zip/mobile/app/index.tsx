import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, radius, typography } from '@/constants/theme';
import { useAppStore } from '@/lib/store';
import { IconCircle, Badge, Card } from '@/components/ui';

const QUICK_ACTIONS = [
  {
    key: 'chat',
    title: 'Chat',
    desc: 'Talk to your agent',
    icon: 'chatbubbles' as const,
    color: colors.primary,
    route: '/chat',
  },
  {
    key: 'briefing',
    title: 'Daily Briefing',
    desc: 'Today at a glance',
    icon: 'sunny' as const,
    color: colors.accent,
    route: '/briefing',
  },
  {
    key: 'approvals',
    title: 'Approvals',
    desc: 'Review actions',
    icon: 'checkmark-done' as const,
    color: colors.warning,
    route: '/approvals',
  },
  {
    key: 'settings',
    title: 'Settings',
    desc: 'Accounts & prefs',
    icon: 'settings' as const,
    color: colors.textSecondary,
    route: '/settings',
  },
];

export default function HomeScreen() {
  const router = useRouter();
  const { user, todayBriefing, pendingApprovals } = useAppStore();
  const pendingCount = pendingApprovals.filter((a) => a.status === 'pending').length;
  const firstName = user?.name?.split(' ')[0] || 'there';

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.hero}>
          <Text style={styles.greeting}>Hey {firstName}</Text>
          <Text style={styles.tagline}>Your Life Agent is standing by</Text>
        </View>

        <View style={styles.grid}>
          {QUICK_ACTIONS.map((item) => (
            <TouchableOpacity
              key={item.key}
              style={styles.actionCard}
              onPress={() => router.push(item.route as any)}
              activeOpacity={0.8}
            >
              <View style={styles.actionTop}>
                <IconCircle name={item.icon} color={item.color} size={44} />
                {item.key === 'approvals' && pendingCount > 0 && (
                  <View style={styles.badgeWrap}>
                    <Badge label={pendingCount} color={colors.warning} />
                  </View>
                )}
              </View>
              <Text style={styles.actionTitle}>{item.title}</Text>
              <Text style={styles.actionDesc}>
                {item.key === 'briefing' && todayBriefing
                  ? 'View today'
                  : item.key === 'approvals' && pendingCount > 0
                    ? `${pendingCount} pending`
                    : item.desc}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <Card style={styles.statusCard}>
          <Text style={styles.statusLabel}>System</Text>
          <View style={styles.statusRow}>
            <View style={[styles.dot, { backgroundColor: colors.success }]} />
            <Text style={styles.statusText}>Agent online</Text>
          </View>
          <View style={styles.statusRow}>
            <View
              style={[
                styles.dot,
                { backgroundColor: user ? colors.success : colors.textMuted },
              ]}
            />
            <Text style={styles.statusText}>
              {user ? 'Accounts ready' : 'Connect Google in Settings'}
            </Text>
          </View>
        </Card>

        <View style={styles.tip}>
          <Ionicons name="sparkles" size={16} color={colors.accent} />
          <Text style={styles.tipText}>
            Try asking “What’s on my calendar today?” in Chat
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
    gap: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  hero: {
    marginTop: spacing.sm,
    marginBottom: spacing.xs,
  },
  greeting: {
    ...typography.hero,
    color: colors.text,
  },
  tagline: {
    ...typography.body,
    color: colors.textSecondary,
    marginTop: 6,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionCard: {
    width: '47.5%',
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    minHeight: 130,
  },
  actionTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 14,
  },
  badgeWrap: {
    marginTop: 2,
  },
  actionTitle: {
    ...typography.subtitle,
    color: colors.text,
    fontSize: 16,
  },
  actionDesc: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: 3,
  },
  statusCard: {
    gap: 10,
  },
  statusLabel: {
    ...typography.label,
    color: colors.textMuted,
    marginBottom: 2,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    ...typography.body,
    color: colors.text,
    fontSize: 14,
  },
  tip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: colors.accentSoft,
    borderRadius: radius.md,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: colors.accent + '25',
  },
  tipText: {
    ...typography.caption,
    color: colors.accent,
    flex: 1,
    lineHeight: 18,
  },
});
