# Build Life Agent APK with GitHub Codespaces

Follow these steps exactly.

## 1. Create a GitHub repo and open Codespaces

1. Go to [github.com/new](https://github.com/new)
2. Create a new repository (e.g. `life-agent`)
3. Upload / push the contents of the `life-agent` folder into it
4. Click the green **<> Code** button → **Codespaces** tab → **Create codespace on main**

Wait for the Codespace to fully start (terminal ready).

## 2. Build the APK

In the Codespaces terminal run:

```bash
cd mobile
npm install
npm install -g eas-cli
eas login
```

(Log in with your Expo account. Create one free at https://expo.dev/signup if needed.)

Then:

```bash
eas build:configure
```

Press Enter to accept defaults.

Finally build the APK:

```bash
eas build -p android --profile preview
```

- When asked, choose **APK** (not AAB)
- Confirm any prompts

The build runs in Expo’s cloud (usually 8–15 minutes).  
When it finishes you will get a **download link**.

## 3. Install on your Android phone

1. Open the download link **on your phone**
2. Download the `.apk`
3. Open the file → Allow install from this source if asked
4. Install

That’s it — Life Agent will appear on your home screen.

---

### Notes

- The first build can take longer.
- The current APK uses **demo data** (chat, briefing, approvals work offline).
- Google Calendar/Gmail connection needs a real backend URL + OAuth credentials later.
- You can rebuild anytime with the same `eas build` command.
